<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_user');
		$this->load->model('model_dashboard');
		
		$authenticated = $this->session->authenticated;

		if($authenticated != true){
			$url=base_url('login/login_pakar');
			redirect($url, 'refresh');
		}
	}

	public function index()
	{
		$data['data_pasien'] 	 = $this->model_dashboard->data_pasien();
		$data['pertanyaan'] 	 = $this->model_dashboard->pertanyaan();
		$data['data_prediksi'] 	 = $this->model_dashboard->data_prediksi();
		$data['data_penanganan'] = $this->model_dashboard->data_penanganan();
		$this->load->view('admin/dashboard/beranda', $data);
	}

	public function profil()
	{
		$username = $this->session->username;
		$data['data_admin'] = $this->model_user->data_admin("WHERE username = '$username'");
		$this->load->view('admin/profil/profil', $data);
	}

	public function update_profil(){

		$password = md5($this->input->post('password'));
		$username = $this->input->post('username');

	    $cek_password = $this->db->query("SELECT password FROM admin WHERE username = '$username';");
		foreach ($cek_password ->result_array() as $row){
	        $password_lama      = $row['password'];
	        if($password_lama == $password){
	    		$data = array(
			      'username' => $username,
			      'nama_lengkap' => $this->input->post('nama'),
			    );

			    $res = $this->model_user->ubah_profil($data);
			    if($res=1){
				    header('location:'.base_url().'login/login_pakar');
				    $this->session->set_flashdata("pesan", "ubah-profil");
			    }
		    }else{
		    	header('location:'.base_url().'admin/dashboard/profil');
				$this->session->set_flashdata("pesan", "gagal");
		    }
	    }
	}

	public function update_password(){

		$password_lama = md5($this->input->post('password_lama'));
		$password_baru = md5($this->input->post('password_baru'));
		$username = $this->input->post('username');

	    $cek_password = $this->db->query("SELECT password FROM admin WHERE username = '$username';");
		foreach ($cek_password ->result_array() as $row){
	        $password_db      = $row['password'];
	        if($password_db == $password_lama){
	    		$data = array(
			      'username' => $username,
			      'password' => $password_baru,
			    );

			    $res = $this->model_user->ubah_password($data);
			    if($res=1){
				    header('location:'.base_url().'login/login_pakar');
				    $this->session->set_flashdata("pesan", "ubah-password");
			    }
		    }else{
		    	header('location:'.base_url().'admin/dashboard/profil');
				$this->session->set_flashdata("pesan", "ubah-password-gagal");
		    }
	    }
	}

	public function tes(){
		$cek_gejala = $this->db->query("SELECT * FROM data_gejala");
		foreach ($cek_gejala ->result_array() as $row){
			$id      = $row['id'];
			$gejala  = $row['gejala'];

			$data['data_gejala'] = $gejala; 

			$cek_sub_gejala = $this->db->query("SELECT * FROM data_sub_gejala WHERE id_gejala = '$id'");
			foreach ($cek_sub_gejala ->result_array() as $row){
				$sub_gejala      = $row['sub_gejala'];
				$data['data_sub_gejala'] = $sub_gejala;
				$this->load->view('admin/testing', $data);
			}
		}
	}

}
