<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Konsultasi extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_konsultasi');
		// $this->load->model('model_alumni');
	}

	public function index()
	{
		$hapus    = $this->db->query("TRUNCATE jawaban");
		$ambil_id = $this->db->query("SELECT data_gejala.`id` AS id_gejala, data_sub_gejala.`id` AS id_sub_gejala FROM data_gejala JOIN data_sub_gejala ON data_gejala.`id` = data_sub_gejala.`id_gejala` ORDER BY data_gejala.`id`;");
		foreach ($ambil_id ->result_array() as $row){
	        $id_gejala       = $row['id_gejala'];
	        $id_sub_gejala   = $row['id_sub_gejala'];

	        $data = array(
		      'id_gejala' => $id_gejala,	
		      'id_sub_gejala' => $id_sub_gejala,
		      'jawaban' => '5',
		      'ket' => '',
		    );

		    $simpan  = $this->model_konsultasi->simpan('jawaban', $data);
	    }

		$data['hasil_konsultasi'] = $this->model_konsultasi->hasil_konsultasi();
		$this->load->view('user/konsultasi/hasil_konsultasi', $data);
	}

	public function histori()
	{
		$data['histori_konsultasi'] = $this->model_konsultasi->hasil_konsultasi();
		$this->load->view('user/konsultasi/histori', $data);
	}

	public function kode()
	{
		$cek_kode = $this->db->query("SELECT max(kode_konsul) as maxKode FROM hasil_konsultasi");
		foreach ($cek_kode ->result_array() as $row){
	        $kode   = $row['maxKode'];
	        $noUrut = (int) substr($kode, 2, 4);
				$noUrut++;
			$kode_karakter = "KR";
			$kode 		   = $kode_karakter . sprintf("%04s", $noUrut);
			echo $kode;
	    }
	}

	public function simpan(){
		$id_user = $this->session->id;
		$data = array(
	      'id_user' => $id_user,
	      'jenis_kelamin' => $this->input->post('jenis_kelamin'),
	      'usia' => $this->input->post('usia'),
	    );
	    $res = $this->model_konsultasi->update_detail_pasien($data);

	    redirect('user/konsultasi/konsultasi');
	}

	public function konsultasi()
	{
		$id_user = $this->session->id;
		$data['pertanyaan'] = $this->model_konsultasi->pertanyaan();
		$cek_jml_pertanyaan	= $this->db->query("SELECT id_gejala FROM jawaban WHERE ket = 0 ORDER BY id ASC LIMIT 1")->num_rows();
		if($cek_jml_pertanyaan > 0){
			
			$cek_id_gejala = $this->db->query("SELECT id_gejala FROM jawaban WHERE ket = 0 ORDER BY id ASC LIMIT 1");
			foreach ($cek_id_gejala ->result_array() as $row){
				$id_gejala = $row['id_gejala'];

				$data['data_pasien'] = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id_user` = '$id_user'");
				$data['data_gejala'] = $this->model_konsultasi->gejala("WHERE data_gejala.`id` = '$id_gejala'");
				$data['pertanyaan']  = $this->model_konsultasi->pertanyaan("WHERE data_sub_gejala.id_gejala = '$id_gejala'");
				$this->load->view('user/konsultasi/konsultasi', $data);

			}

		}else{
			// proses jawaban
			$jumlah_skor = $this->db->query("SELECT SUM(jawaban) AS jumlah FROM jawaban");
			foreach ($jumlah_skor ->result_array() as $row){
		        $jumlah       = $row['jumlah'];

		        //cek jumlah
		        $cek_jumlah	= $this->db->query("SELECT * FROM data_penanganan WHERE jumlah_max_skor >= $jumlah ORDER BY jumlah_max_skor ASC LIMIT 1")->num_rows();
				if($cek_jumlah > 0){
					$data['data_pasien'] = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id_user` = '$id_user'");
					$data['hasil_tes'] = $this->model_konsultasi->hasil_tes("WHERE jumlah_max_skor >= '$jumlah'");
					$this->load->view('user/konsultasi/hasil', $data);
				}else{
					$data['data_pasien'] = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id_user` = '$id_user'");
					$data['hasil_tes'] = $this->model_konsultasi->hasil_tes2();
					$this->load->view('user/konsultasi/hasil', $data);
				}
				
			}
		}
	}

	public function jawaban(){

		$id_sub_gejala = $this->input->post('id_sub_gejala');
		$jawaban = $this->input->post('jawaban');

		$result = array();
		foreach ($id_sub_gejala as $key => $value) {

			$jawabannya = $jawaban[$key];
			if($jawabannya === NULL){

				$result[] = array(
					"id_sub_gejala" => $id_sub_gejala[$key],
					"jawaban" => $this->input->post('jawaban')[$key],
				);
				// $update = $this->db->update_batch('jawaban', $result, 'id_sub_gejala');

				header('location:'.base_url().'user/konsultasi/konsultasi');
				$this->session->set_flashdata("pesan", "Gagal");

			}else{

				$result[] = array(
					"id_sub_gejala" => $id_sub_gejala[$key],
					"jawaban" => $this->input->post('jawaban')[$key],
					"ket" => '1',
				);

				$update = $this->db->update_batch('jawaban', $result, 'id_sub_gejala');
			}
		}

		redirect('user/konsultasi/konsultasi');
		
	}

	public function petunjuk()
	{
		$this->load->view('user/konsultasi/petunjuk');
	}

	public function tes()
	{
		$this->load->view('user/konsultasi/tes');
	}

}
