<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coba extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_konsultasi');
	}

	public function index()
	{
		$id_user = $this->session->id;
		$hapus    = $this->db->query("TRUNCATE jawaban");
		$data['hasil_konsultasi'] = $this->model_konsultasi->hasil_konsultasi("WHERE hasil_konsultasi.`id_user` = $id_user ORDER BY hasil_konsultasi.`id` DESC LIMIT 1");
		$this->load->view('user/konsultasi/hasil_konsultasi', $data);
	}

	public function histori()
	{
		$id_user = $this->session->id;
		$data['histori_konsultasi'] = $this->model_konsultasi->hasil_konsultasi2("WHERE hasil_konsultasi.`id_user` = $id_user");
		$this->load->view('user/konsultasi/histori', $data);
	}

	public function kode()
	{
		$cek_kode = $this->db->query("SELECT max(kode_konsul) as maxKode FROM hasil_konsultasi");
		foreach ($cek_kode ->result_array() as $row){
	        $kode   = $row['maxKode'];
	        $noUrut = (int) substr($kode, 2, 4);
				$noUrut++;
			$kode_karakter = "KR";
			$kode 		   = $kode_karakter . sprintf("%04s", $noUrut);
			echo $kode;
	    }
	}

	public function simpan(){
		$data = array(
	      'nim' => $this->input->post('nim'),
	      'nama_lengkap' => $this->input->post('nama'),
	      'id_fakultas' => $this->input->post('fakultas'),
	      'id_jurusan' => $this->input->post('jurusan'),
	      'usia' => $this->input->post('usia'),
	      'jenis_kelamin' => $this->input->post('jenis_kelamin'),
	    );
	    $simpan  = $this->model_konsultasi->simpan('data_pasien', $data);

	    redirect('user/konsultasi/konsultasi/');
	}

	public function konsultasi($nama='')
	{
		$namanya = $nama;

		$data['data_pasien'] = $this->model_konsultasi->data_pasien("ORDER BY data_pasien.id DESC LIMIT 1");
		$data['pertanyaan']  = $this->model_konsultasi->pertanyaan();
		$this->load->view('user/konsultasi/konsultasi', $data);
	}

	

	public function jawaban(){
		$id_pasien = $this->input->post('id_pasien');

		$hapus_nilai_variabel = $this->db->query("TRUNCATE nilai_variabel");
		$hapus_kolom_jawaban   = $this->db->query("TRUNCATE kolom_jawaban");
		$data = array(
		      'id' => 1,
		);
		$simpan  = $this->model_konsultasi->simpan('kolom_jawaban', $data);

		$hapus    = $this->db->query("TRUNCATE jawaban");
		$cek_jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

		for($i = 1; $i<=$cek_jumlah_pertanyaan; $i++){
			
			$kode_pertanyaan = $this->input->post('kode_pertanyaan'.$i);
			$jawaban_1		 = $this->input->post('jawaban_1'.$i);
			$jawaban_2		 = $this->input->post('jawaban_2'.$i);

			$data = array(
		      'kode_pertanyaan' => $kode_pertanyaan,
		      'jawaban_1' => $jawaban_1,
		      'jawaban_2' => $jawaban_2,
			);

			$simpan  = $this->model_konsultasi->simpan('jawaban', $data);
		}

		// Proses Algoritma
		$ambil_jawaban = $this->db->query("SELECT * FROM jawaban");
		foreach ($ambil_jawaban ->result_array() as $row){
			$id 		= $row['id'];
        	$jawaban_1  = $row['jawaban_1'];
        	$jawaban_2  = $row['jawaban_2'];
        	$jawabannya = ($jawaban_1 + $jawaban_2) / 2;
        	if($jawabannya == 0){
        		$hasil = 0;
        	}elseif ($jawabannya == 0.5) {
        		$hasil = 0;
        	}elseif ($jawabannya == 1) {
        		$hasil = 1;
        	}elseif ($jawabannya == 1.5) {
        		$hasil = 1;
        	}elseif ($jawabannya == 2) {
        		$hasil = 2;
        	}elseif ($jawabannya == 3) {
        		$hasil = 3;
        	}

        	$update_kolom_jawaban = $this->db->query("UPDATE kolom_jawaban SET x".$id." = $hasil WHERE id = 1");
        }

        $jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

        $ambil_jawaban_2 = $this->db->query("SELECT * FROM kolom_jawaban");
		foreach ($ambil_jawaban_2 ->result_array() as $row){
			
			$jawaban_user = '';
			for ($i=1; $i <= $jumlah_pertanyaan; $i++) {
				$x  = $row['x'.$i];
				$jawaban_user .= $x;
			}
		}

		$ambil_data_latih = $this->db->query("SELECT * FROM data_latih");
		foreach ($ambil_data_latih ->result_array() as $row){
			$id  = $row['id'];

			$jawaban_latih = '';
			for ($i=1; $i <= $jumlah_pertanyaan; $i++) {
				$x  = $row['x'.$i];
				$jawaban_latih .= $x;
			}

			similar_text($jawaban_user, $jawaban_latih, $persen);
			// echo "$persen <br>";
			$data = array(
		      'id_data_latih' => $id,
		      'nilai' => $persen,
			);

			$simpan  = $this->model_konsultasi->simpan('nilai_variabel', $data);
		}


		// sampai sini
		$ambil_id_data_latih = $this->db->query("SELECT * FROM nilai_variabel ORDER BY nilai DESC LIMIT 1");
		foreach ($ambil_id_data_latih ->result_array() as $row){
			$id_data_latih  = $row['id_data_latih'];
		}

		// $ambil_bobot_w = $this->db->query("SELECT * FROM bobot_w WHERE id_data_latih = $id_data_latih");
		// foreach ($ambil_bobot_w ->result_array() as $row){
		// 	for($i = 0; $i <= $jumlah_pertanyaan; $i++){
		// 		$w  = $row['w'.$i];
		// 		echo "w$i = $w <br>";
		// 	}
		// }

		// FEEDFORWARD
		$total_perkalian   = 0;
		$total_perkalian_w = 0;
		$w0 = 0.13;

		$ambil_input = $this->db->query("SELECT * FROM data_normalisasi WHERE id = $id_data_latih");
		foreach ($ambil_input ->result_array() as $row){
			for($i = 1; $i <= $jumlah_pertanyaan; $i++){
				$x  = $row['x'.$i];
				$target = $row['target'];

				$total = "zin$i";
				$v0    = "0.".(rand (0, 100));

				// inisial bobot w
				$w     = "0.".(rand (0, 100));
				$x      = $row['x'.$i];

				for ($b=1; $b <= $jumlah_pertanyaan; $b++) { 

					// inisial bobot v
					$v = "0.".(rand (0, 100));

					$perkalian = ($v * $x);
					
					$total_perkalian += $perkalian;
				}

				$totalnya = $total_perkalian + $v0;	
				// echo "Dengan Perulangan zin$i = $totalnya <br>";
				$total_perkalian = 0;

				// >>pengaktifan 
				$z = 1 / (1 + pow(2.7182818284590452354, -$totalnya));
				// echo "z$i : $z<br> ";

				//php Operasi pada output layer :
				// >> Perkalian :
				// Y_in = W0 + W1*Z1 + W2*Z2 + W3*Z3 + W4*Z4
				$perkalian_w = ($w * $z);
				$total_perkalian_w += $perkalian_w;
				$y_in = $w0 + $total_perkalian_w;
			}

			// >> Pengaktifan :
			$Y = 1 / (1 + pow(2.7182818284590452354, -$y_in));
			$y = round($Y, 5);
			echo "y = $y";

		}

		//akumulasikan
		$cek_target = $this->db->query("SELECT * FROM data_normalisasi WHERE id = $id_data_latih");
		foreach ($cek_target ->result_array() as $row){
	        $target   = $row['target'];

			$cek_kode = $this->db->query("SELECT max(kode_konsul) as maxKode FROM hasil_konsultasi");
			foreach ($cek_kode ->result_array() as $row){
		        $kode   = $row['maxKode'];
		        $noUrut = (int) substr($kode, 2, 4);
					$noUrut++;
				$kode_karakter = "KR";
				$kode 		   = $kode_karakter . sprintf("%04s", $noUrut);

				$cek_kode_penanganan = $this->db->query("SELECT * FROM data_penanganan WHERE jumlah_max_skor = '$target'");
				foreach ($cek_kode_penanganan ->result_array() as $row){

					$id_user = $this->session->id;
					$kode_penanganan   = $row['kode_penanganan'];

					$data = array(
				      'id_pasien' => $id_pasien,
				      'kode_konsul' => $kode,
				      'tanggal_cek' => date('Y-m-d'),
				      'jumlah' => $target,
				      'kode_penanganan' => $kode_penanganan,
					);

					$simpan  = $this->model_konsultasi->simpan('hasil_konsultasi', $data);

					$data['data_pasien']       = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id` = '$id_pasien'");
					$data['hasil_tes']         = $this->model_konsultasi->hasil_tes("WHERE jumlah_max_skor >= '$target'");
					$data['skor']              = $target;
					// $data['total_kemungkinan'] = $total_kemungkinan;

					$this->load->view('user/konsultasi/hasil', $data);
				}
			}
        }
		
	}

	public function petunjuk()
	{
		$this->load->view('user/konsultasi/petunjuk');
	}

	// public function jawaban2(){
	// 	$id_pasien = $this->input->post('id_pasien');

	// 	$hapus    = $this->db->query("TRUNCATE jawaban");
	// 	$cek_jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

	// 	for($i = 1; $i<=$cek_jumlah_pertanyaan; $i++){
			
	// 		$kode_pertanyaan = $this->input->post('kode_pertanyaan'.$i);
	// 		$jawaban_1		 = $this->input->post('jawaban_1'.$i);
	// 		$jawaban_2		 = $this->input->post('jawaban_2'.$i);

	// 		$data = array(
	// 	      'kode_pertanyaan' => $kode_pertanyaan,
	// 	      'jawaban_1' => $jawaban_1,
	// 	      'jawaban_2' => $jawaban_2,
	// 		);

	// 		$simpan  = $this->model_konsultasi->simpan('jawaban', $data);
	// 	}

	// 	//akumulasikan
	// 	$total = $this->db->query("SELECT (SUM(jawaban_1) + SUM(jawaban_2)) AS total FROM jawaban");
	// 	$total_kemungkinan = ($cek_jumlah_pertanyaan * 3) * 2;

	// 	foreach ($total ->result_array() as $row){
 //        	$skor   = $row['total'];

 //        	//cek jumlah
	//         $cek_jumlah	= $this->db->query("SELECT * FROM data_penanganan WHERE jumlah_max_skor >= $skor ORDER BY jumlah_max_skor ASC LIMIT 1")->num_rows();
	// 		if($cek_jumlah > 0){

	// 			$cek_kode = $this->db->query("SELECT max(kode_konsul) as maxKode FROM hasil_konsultasi");
	// 			foreach ($cek_kode ->result_array() as $row){
	// 		        $kode   = $row['maxKode'];
	// 		        $noUrut = (int) substr($kode, 2, 4);
	// 					$noUrut++;
	// 				$kode_karakter = "KR";
	// 				$kode 		   = $kode_karakter . sprintf("%04s", $noUrut);

	// 				$cek_kode_penanganan = $this->db->query("SELECT * FROM data_penanganan WHERE jumlah_max_skor >= '$skor' ORDER BY jumlah_max_skor ASC LIMIT 1");
	// 				foreach ($cek_kode_penanganan ->result_array() as $row){

	// 					$id_user = $this->session->id;
	// 					$kode_penanganan   = $row['kode_penanganan'];

	// 					$data = array(
	// 				      'id_pasien' => $id_pasien,
	// 				      'kode_konsul' => $kode,
	// 				      'tanggal_cek' => date('Y-m-d'),
	// 				      'jumlah' => $skor,
	// 				      'kode_penanganan' => $kode_penanganan,
	// 					);

	// 					$simpan  = $this->model_konsultasi->simpan('hasil_konsultasi', $data);

	// 					$data['data_pasien']       = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id` = '$id_pasien'");
	// 					$data['hasil_tes']         = $this->model_konsultasi->hasil_tes("WHERE jumlah_max_skor >= '$skor'");
	// 					$data['skor']              = $skor;
	// 					$data['total_kemungkinan'] = $total_kemungkinan;

	// 					$this->load->view('user/konsultasi/hasil', $data);
	// 				}
	// 			}

				
	// 		}else{
	// 			$data['data_pasien'] = $this->model_konsultasi->data_pasien("WHERE data_pasien.`id_user` = '$id_user'");
	// 			$data['hasil_tes'] = $this->model_konsultasi->hasil_tes2();
	// 			$this->load->view('user/konsultasi/hasil', $data);
	// 		}
 //        }
		
	// }

}
