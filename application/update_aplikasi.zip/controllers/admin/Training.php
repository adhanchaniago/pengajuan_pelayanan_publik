<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Training extends CI_Controller {

	private $filename = "import_data"; // Kita tentukan nama filenya

	public function __construct(){
		parent::__construct();
		$this->load->model('model_training');
		$this->load->model('model_dashboard');
		$this->load->model('model_penanganan');
		
		$authenticated = $this->session->authenticated;

		if($authenticated != true){
			$url=base_url('login/login_pakar');
			redirect($url, 'refresh');
		}
	}

	public function index()
	{
		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
		
		$data['data_latih'] = $this->model_training->training();
		$this->load->view('admin/training/training', $data);
	}

	public function tambah()
	{
		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
		$data['data_penanganan']   = $this->model_penanganan->data_penanganan();
		$this->load->view('admin/training/tambah', $data);
	}

	public function simpan(){
		$jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

		$data = array(
		    'target' => $this->input->post('target'),
		);
		$this->model_training->simpan('data_latih', $data);

		$ambil_id_terakhir = $this->db->query("SELECT id FROM data_latih ORDER BY id DESC LIMIT 1");
		foreach ($ambil_id_terakhir ->result_array() as $row){
			$id  = $row["id"];

			for($a = 1; $a <= $jumlah_pertanyaan; $a++) { 

				$x = $this->input->post('x'.$a);
				$this->db->query("UPDATE data_latih SET x$a = $x WHERE id = $id");
			}
		}
		header('location:'.base_url().'admin/training');
	    $this->session->set_flashdata("pesan", "tambah");
  	}

  	public function hapus($kode_id = 0){
	    $id = $kode_id;
        $result = $this->model_training->hapus('data_latih',array('id' => $kode_id));
        $result = $this->model_training->hapus('data_normalisasi',array('id' => $kode_id));

	    if($result ==  1){
	    header('location:'.base_url().'admin/training');
	    $this->session->set_flashdata("pesan", "hapus");
		}
	}

  	public function hapus_semua(){

		$hapus = $this->db->query("TRUNCATE data_latih");
		if($hapus){
			header('location:'.base_url().'admin/training');
		    $this->session->set_flashdata("pesan", "hapus_semua");
		}
  	}

  	public function edit($id = 0){
  		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
		$data['data_penanganan']   = $this->model_penanganan->data_penanganan();
	    $data['data_latih'] = $this->model_training->edit("WHERE id = '$id'");
        $this->load->view('admin/training/edit',$data);
  	}

  	public function update(){

  		$jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
      	$id     = $this->input->post('id');
     	$target = $this->input->post('target');

	    for($a = 1; $a <= $jumlah_pertanyaan; $a++) { 
			$x = $this->input->post('x'.$a);
			$this->db->query("UPDATE data_latih SET x$a = $x WHERE id = $id");
		}

		$res = $this->db->query("UPDATE data_latih SET target = $target WHERE id = $id");
	    if($res=1){
		      header('location:'.base_url().'admin/training');
		      $this->session->set_flashdata("pesan", "update");
	    }
	}

	public function detail($id = 0){
		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
	    $data['data_latih'] = $this->model_training->detail("WHERE id = '$id'");
        $this->load->view('admin/training/detail',$data);
  	}

  	public function normalisasi(){

  		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

  		$hapus = $this->db->query("TRUNCATE bobot_w");
  		$hapus = $this->db->query("TRUNCATE data_normalisasi");
  		$ambil_id = $this->db->query("SELECT id, target FROM data_latih");
		foreach ($ambil_id ->result_array() as $row){
			$id   = $row['id'];
			$target   = $row['target'];

			 $data = array(
	      		'id' => $id,
	      		'target' => $target,
	      	 );
	   		 $simpan  = $this->model_training->simpan('data_normalisasi', $data);	

	   		 $update_ket = $this->db->query("UPDATE data_latih SET ket = 0 Where id = $id ");   	
	   	}


	   	for ($i=1; $i <= $jumlah_pertanyaan; $i++) { 
	   		
	  		$nilai_terkecil = $this->db->query("SELECT x".$i." FROM data_latih ORDER BY x".$i." ASC LIMIT 1");
			foreach ($nilai_terkecil ->result_array() as $row){
				$x_kecil  = $row["x".$i];


				$nilai_terbesar= $this->db->query("SELECT x".$i." FROM data_latih ORDER BY x".$i." DESC LIMIT 1");
				foreach ($nilai_terbesar ->result_array() as $row){
					$x_besar   = $row["x".$i];

					$cek_id = $this->db->query("SELECT id FROM data_normalisasi");
					foreach ($cek_id ->result_array() as $row){
						$id   = $row['id'];

						$normalisai = $this->db->query("SELECT ((0.8 * (x$i - $x_kecil))/($x_besar - $x_kecil) + 0.1) AS normal FROM data_latih Where id = $id");
						foreach ($normalisai ->result_array() as $row){

							$normal   = $row['normal'];
							$normal   = round($normal, 5);

							$update_normalisasi = $this->db->query("UPDATE data_normalisasi SET x$i = $normal Where id = $id");
						}
					}
				}
			}
		}
		if($update_normalisasi){
			header('location:'.base_url().'admin/training');
		    $this->session->set_flashdata("pesan", "normalisasi");
		}
  	}

  	public function data_normalisasi()
	{
		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
		$data['data_normalisasi'] = $this->model_training->normalisasi();
		$this->load->view('admin/training/normalisasi', $data);
	}

	public function detail_normalisasi($id = 0){
		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
	    $data['data_normalisasi'] = $this->model_training->detail_normalisasi("WHERE id = '$id'");
        $this->load->view('admin/training/detail_normalisasi',$data);
  	}

  	public function import(){

		$data = array(); // Buat variabel $data sebagai array
		
		if(isset($_POST['preview'])){ // Jika user menekan tombol Preview pada form
			// lakukan upload file dengan memanggil function upload yang ada di SiswaModel.php
			$upload = $this->model_training->upload_file($this->filename);
			
			if($upload['result'] == "success"){ // Jika proses upload sukses
				// Load plugin PHPExcel nya
				include APPPATH.'third_party/PHPExcel/PHPExcel.php';
				
				$excelreader = new PHPExcel_Reader_Excel2007();
				$loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx'); // Load file yang tadi diupload ke folder excel
				$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
				
				// Masukan variabel $sheet ke dalam array data yang nantinya akan di kirim ke file form.php
				// Variabel $sheet tersebut berisi data-data yang sudah diinput di dalam excel yang sudha di upload sebelumnya
				$data['sheet'] = $sheet; 
			}else{ // Jika proses upload gagal
				$data['upload_error'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
			}
		}

		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
		$data['jumlah_pertanyaan'] = $jumlah_pertanyaan;
		$this->load->view('admin/training/import', $data);
	}

	public function import_training(){
		// Load plugin PHPExcel nya
		include APPPATH.'third_party/PHPExcel/PHPExcel.php';
		
		$excelreader = new PHPExcel_Reader_Excel2007();
		$loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx');
		$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
		
		// Buat sebuah variabel array untuk menampung array data yg akan kita insert ke database
		$data = array();
		
		$numrow = 1;
		foreach($sheet as $row){
			if($numrow > 1){
				// Kita push (add) array data ke variabel data
				array_push($data, array(
					'x1'=>$row['A'], // Insert data nama dari kolom B di excel
					'x2'=>$row['B'], // Insert data jenis kelamin dari kolom C di excel
					'x3'=>$row['C'], // Insert data jenis kelamin dari kolom C di excel
					'x4'=>$row['D'], // Insert data jenis kelamin dari kolom C di excel
					'x5'=>$row['E'], // Insert data alamat dari kolom D di excel
					'x6'=>$row['F'], // Insert data alamat dari kolom D di exce
					'x7'=>$row['G'], // Insert data alamat dari kolom D di excel
					'x8'=>$row['H'], // Insert data alamat dari kolom D di excel
					'x9'=>$row['I'], // Insert data alamat dari kolom D di excel
					'x10'=>$row['J'], // Insert data alamat dari kolom D di excel
					'x11'=>$row['K'], // Insert data alamat dari kolom D di excel
					'x12'=>$row['L'], // Insert data alamat dari kolom D di excel
					'x13'=>$row['M'], // Insert data alamat dari kolom D di excel
					'x14'=>$row['N'], // Insert data alamat dari kolom D di excel
					'x15'=>$row['O'], // Insert data alamat dari kolom D di excel
					'x16'=>$row['P'], // Insert data alamat dari kolom D di excel
					'x17'=>$row['Q'], // Insert data alamat dari kolom D di excel
					'x18'=>$row['R'], // Insert data alamat dari kolom D di excel
					'x19'=>$row['S'], // Insert data alamat dari kolom D di excel
					'x20'=>$row['T'], // Insert data alamat dari kolom D di excel
					'x21'=>$row['U'], // Insert data alamat dari kolom D di excel
					'x22'=>$row['V'], // Insert data alamat dari kolom D di excel
					'x23'=>$row['W'], // Insert data alamat dari kolom D di excel
					'x24'=>$row['X'], // Insert data alamat dari kolom D di excel
					'target'=>$row['Y'], // Insert data alamat dari kolom D di excel
				));
			}

			$numrow++; // Tambah 1 setiap kali looping
		}
		// Panggil fungsi insert_multiple yg telah kita buat sebelumnya di model
		$import = $this->model_training->import($data);

		header('location:'.base_url().'admin/training');
	    $this->session->set_flashdata("pesan", "import");
	}

	public function download(){
		force_download('assets/file/Format_Import.xlsx', NULL);
	}


	public function proses_training($kode=0){

		$update_ket = $this->db->query("UPDATE data_latih SET ket = 1 Where id = $kode ");
		$hapus = $this->db->query("TRUNCATE tampung");
		$jumlah_pertanyaan = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

		// simpan id data latih
		$data = array(
	      'id_data_latih' => $kode,
		);
		$simpan  = $this->model_training->simpan('bobot_w', $data);

		// inisail bobot w0
		$w0 = 0.13;

		$data = array(
	      'bobot_w' => $w0,
		);
		$simpan = $this->model_training->simpan('tampung', $data);

		$total_perkalian   = 0;
		$total_perkalian_w = 0;

		
		$ambil_input = $this->db->query("SELECT * FROM data_normalisasi WHERE id = $kode");
		foreach ($ambil_input ->result_array() as $row){
			$target = $row['target'];

			for ($i=1; $i <= $jumlah_pertanyaan; $i++) { 
				$i     = "$i";
				$total = "zin$i";
				$v0    = "0.".(rand (0, 100));

				// inisial bobot w
				$w     = "0.".(rand (0, 100));
				$x      = $row['x'.$i];

				for ($b=1; $b <= $jumlah_pertanyaan; $b++) { 

					// $x = "x$b";
					$v = "0.".(rand (0, 100));

					$perkalian = ($v * $x);
					
					$total_perkalian += $perkalian;
				}

				$totalnya = $total_perkalian + $v0;	
				// echo "Dengan Perulangan zin$i = $totalnya <br>";
				$total_perkalian = 0;

				// >>pengaktifan 
				$z = 1 / (1 + pow(2.7182818284590452354, -$totalnya));

				// $y_in = $w0 + ($w1 * $z1) + ($w2 * $z2) + ($w3 * $z3);
				$perkalian_w = ($w * $z);
				$total_perkalian_w += $perkalian_w;
				$y_in = $w0 + $total_perkalian_w;

				// simpan bobot sementara
				$data = array(
			      'bobot_w' => $w,
				);
				$simpan = $this->model_training->simpan('tampung', $data);

			} // akhir for

			// >> Pengaktifan :
			$Y = 1 / (1 + pow(2.7182818284590452354, -$y_in));
			$y = round($Y, 5);

			// Error = target – y 
			$error = $target - $y;
			if($error <= 0){
				$ambil_jawaban = $this->db->query("SELECT * FROM tampung");
				foreach ($ambil_jawaban ->result_array() as $row){
					$id 		    = $row['id'];
					$idnya			= $id - 1;
		        	$bobot_w        = $row['bobot_w'];
		        	$update_bobot_w = $this->db->query("UPDATE bobot_w SET w".$idnya." = $bobot_w WHERE id_data_latih = $kode");
		        }

				if($update_bobot_w){
					header('location:'.base_url().'admin/training');
				    $this->session->set_flashdata("pesan", "proses_training");
				}
			}else{

				// δ = (target - y)(y)(1 - y) 
				$S = $error * $y * (1-$y);
				$s = round($S,5);

				// ΔW0 = α * δ 
				$seg_w0 = 0.1 * $s;

				$ambil_input = $this->db->query("SELECT * FROM data_normalisasi WHERE id = $kode");
				foreach ($ambil_input ->result_array() as $row){
					$target = $row['target'];

					for ($i=1; $i <= $jumlah_pertanyaan; $i++) { 
						$i     = "$i";
						$total = "zin$i";
						$v0    = "0.".(rand (0, 100));

						$w     = "0.".(rand (0, 100));
						$x      = $row['x'.$i];


						for ($b=1; $b <= $jumlah_pertanyaan; $b++) { 

							// $x = "x$b";
							$v = "0.".(rand (0, 100));

							$perkalian = ($v * $x);
							
							$total_perkalian += $perkalian;
						}

						$totalnya = $total_perkalian + $v0;	

						$total_perkalian = 0;

						// >>pengaktifan 
						$z = 1 / (1 + pow(2.7182818284590452354, -$totalnya));

						$perkalian_w = ($w * $z);
						$total_perkalian_w += $perkalian_w;
						$y_in = $w0 + $total_perkalian_w;

						// echo "Nilai y_in perulangan = $y_in <br>";

						$seg_w = 0.1 * $s * $z;

						$seg_in = $s * $w;

						$seg_angka = $seg_in * (1/(1 + pow(2.7182818284590452354, -$z))) * (1 - (1/(1 + pow(2.7182818284590452354, -$z))));

						for ($c=1; $c <= $jumlah_pertanyaan; $c++) { 

							$x = "x$c";
							$v = "0.".(rand (0, 100));

							$seg_v = 0.1 * $seg_angka * $x;

							// V11 = V11 + ΔV11
							$v_angka = $v + $seg_v;
							// echo "v$c$i : $v_angka <br>";
						}

						$seg_v = 0.1 * $seg_angka;

						// $v01 = $v01 + $seg_v01;
						$v_angka = $v0 + $seg_v;
						// echo "$v0 : $v_angka <br>";
						
						// W1 = W1 + ΔW1
						$w_angka1 = $w + $seg_w;
						$w_angka1 = round($w_angka1, 5);
						// echo "w$i : $w_angka1 <br>";

						$update_bobot_w = $this->db->query("UPDATE bobot_w SET w".$i." = $w_angka1 WHERE id_data_latih = $kode");

					} // akhir perulangan for
				} // akhir foreach	

				$w_angka = $w0 + $seg_w0;
				$w_angka = round($w_angka, 5);

				$update_bobot_w = $this->db->query("UPDATE bobot_w SET w0 = $w_angka1 WHERE id_data_latih = $kode");
				if($update_bobot_w){
					header('location:'.base_url().'admin/training');
				    $this->session->set_flashdata("pesan", "proses_training");
				}

			}
		}
	}

}