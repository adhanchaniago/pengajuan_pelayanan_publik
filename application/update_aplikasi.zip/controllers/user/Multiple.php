<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Multiple extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_multiple');
	}

	public function index()
	{
		$data['data_update'] = $this->model_multiple->data_jawaban();
		$this->load->view('user/multiple', $data);
	}

	public function update(){

		$id_sub_gejala = $this->input->post('id_sub_gejala');
		$result = array();
		foreach ($id_sub_gejala as $key => $value) {
			$result[] = array(
				"id_sub_gejala" => $id_sub_gejala[$key],
				"nilai_0" => $_POST['nilai_0'][$key],
			);

			$update = $this->db->update_batch('jawaban', $result, 'id_sub_gejala');
		}
	}
}
