<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_pasien');
		
		$authenticated = $this->session->authenticated;

		if($authenticated != true){
			$url=base_url('login/login_pakar');
			redirect($url, 'refresh');
		}
	}

	public function index()
	{
		$data['data_pasien'] = $this->model_pasien->data_pasien();
		$this->load->view('admin/pasien/pasien', $data);
	}

	public function detail($id = 0){
	    $data['detail_pasien'] = $this->model_pasien->detail_pasien("WHERE hasil_konsultasi.`id` = '$id'");
        $this->load->view('admin/pasien/detail',$data);
  	}

	public function hapus($kode_id = 0){
	    $result1 = $this->model_pasien->hapus_pasien('hasil_konsultasi',array('id' => $kode_id));

	    if($result1 == 1){
	    header('location:'.base_url().'admin/pasien');
	    $this->session->set_flashdata("pesan", "hapus-pasien");
		}
	}

	

}
