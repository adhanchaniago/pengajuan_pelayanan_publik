<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penanganan extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_penanganan');
		
		$authenticated = $this->session->authenticated;

		if($authenticated != true){
			$url=base_url('login/login_pakar');
			redirect($url, 'refresh');
		}
	}

	public function index()
	{
		$data['data_penanganan'] = $this->model_penanganan->data_penanganan();
		$this->load->view('admin/penanganan/data_penanganan', $data);
	}

	public function edit($id = 0){
	    $data['data_penanganan'] = $this->model_penanganan->edit("WHERE id = '$id'");
        $this->load->view('admin/penanganan/edit',$data);
  	}

  	public function update(){
  		$id = $this->input->post('id');
  		echo "$id";
	    $data = array(
	      'id' => $this->input->post('id'),
	      'jumlah_max_skor' => $this->input->post('jumlah'),
	      'tingkat_kecemasan' => $this->input->post('tingkat_kecemasan'),
	      'penanganan' => $this->input->post('penanganan'),
	    );
	    $res = $this->model_penanganan->update($data);
	    if($res=1){
		      header('location:'.base_url().'admin/penanganan');
		      $this->session->set_flashdata("pesan", "update");
	    }
	}

	public function tambah(){

		$cek_kode = $this->db->query("SELECT max(kode_penanganan) as maxKode FROM data_penanganan");
		foreach ($cek_kode ->result_array() as $row){
	        $kode   = $row['maxKode'];
	        $noUrut = (int) substr($kode, 2, 2);
				$noUrut++;
			$kode_karakter = "DP";
			$kode 		   = $kode_karakter . sprintf("%02s", $noUrut);
			$data['kode_penanganan'] = $kode;
			$this->load->view('admin/penanganan/tambah', $data);
	    }   
  	}

  	public function simpan(){

  		$data = array(
		      'kode_penanganan' => $this->input->post('kode_penanganan'),
		      'jumlah_max_skor' => $this->input->post('jumlah'),
		      'tingkat_kecemasan' => $this->input->post('tingkat_kecemasan'),
		      'penanganan' => $this->input->post('penanganan'),
		);

		$simpan  = $this->model_penanganan->simpan('data_penanganan', $data);
		if($simpan){
			header('location:'.base_url().'admin/penanganan');
		    $this->session->set_flashdata("pesan", "tambah");
		}
  	}

  	public function hapus($kode_id = 0){
	    $result = $this->model_penanganan->hapus('data_penanganan',array('id' => $kode_id));

	    if($result ==  1){
	    header('location:'.base_url().'admin/penanganan');
	    $this->session->set_flashdata("pesan", "hapus");
		}
	}

	public function hapus_semua(){

		$hapus = $this->db->query("TRUNCATE data_penanganan");
		if($hapus){
			header('location:'.base_url().'admin/penanganan');
		    $this->session->set_flashdata("pesan", "hapus_semua");
		}
  	}

}
