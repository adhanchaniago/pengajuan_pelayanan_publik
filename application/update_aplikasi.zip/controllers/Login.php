<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('model_login');
		$this->load->model('model_user');
	}

	public function index()
	{
		redirect('user/dashboard');
	}

	public function login_pakar()
	{

		if($this->session->userdata('authenticated')) // Jika user sudah login (Session authenticated ditemukan)
			redirect('admin/dashboard'); // Redirect ke page welcome

		$this->load->view('login_pakar');
	}

	public function cek_login_pakar()
	{
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));

		$user = $this->model_login->get($username); // Panggil fungsi get yang ada di UserModel.php
		
		if(empty($user)){ // Jika hasilnya kosong / user tidak ditemukan
			header('location:'.base_url().'login/login_pakar');
			$this->session->set_flashdata("pesan","gagal");
		}else{
			if($password == $user->password){ // Jika password yang diinput sama dengan password yang didatabase
				$session = array(
					'authenticated'=>true, // Buat session authenticated dengan value true
					'username'=>$user->username,  // Buat session username
					'nama'=>$user->nama_lengkap // Buat session authenticated
				);

				$this->session->set_userdata('masuk',TRUE);
				$this->session->set_userdata($session); // Buat session sesuai $session
				redirect('admin/dashboard'); // Redirect ke halaman welcome
			}else{
				header('location:'.base_url().'login/login_pakar');
				$this->session->set_flashdata("pesan","password_salah");
			}
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		header('location:'.base_url());
	}

	public function logout_pakar()
	{
		$this->session->sess_destroy();
		header('location:'.base_url('login/login_pakar'));
	}

	public function daftar()
	{
		$this->load->view('daftar');
	}

	public function proses_daftar(){
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required|min_length[6]');
		$this->form_validation->set_rules('konf_password','Konfirmasi Password','required|min_length[6]|matches[password]');
 
		if($this->form_validation->run() != false){
			$nama 	  = $this->input->post('nama');
			$username = $this->input->post('username');
			$password = md5($this->input->post('password'));

			$cek_username = $this->db->query("SELECT * FROM user WHERE username = '$username';")->num_rows();
			if($cek_username > 0){
				header('location:'.base_url().'login/daftar');
				$this->session->set_flashdata("pesan", "Pendaftaran Gagal");
			}else{
				$data = array(
			      'nama_lengkap' => $nama,
			      'username' => $username,
			      'password' => $password,
			    );
				$simpan  = $this->model_login->simpan('user', $data);

			    $data_id_user = $this->db->query("SELECT * FROM user WHERE username = '$username';");
				foreach ($data_id_user ->result_array() as $row){
		       		$id_user      = $row['id'];

				    $data2 = array(
				      'id_user' => $id_user,
				    );
				    $simpan2  = $this->model_user->simpan('data_pasien', $data2);
				}

			    if($simpan){
				header('location:'.base_url().'login');
			    $this->session->set_flashdata("pesan", "Pendaftaran Sukses");
			}
			}

		}else{
			$this->load->view('daftar');	
		}
	}
}
