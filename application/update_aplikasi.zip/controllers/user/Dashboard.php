<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_user');
		$this->load->model('model_dashboard');
		$this->load->helper('url');
	}

	public function index()
	{
		$data['data_fakultas'] = $this->model_dashboard->fakultas();
		$this->load->view('user/dashboard/beranda', $data);
	}

	public function jurusan(){
        $id   = $this->input->post('id');
        $data = $this->model_dashboard->jurusan($id);
        echo json_encode($data);
    }

	public function profil()
	{
		$username = $this->session->username;
		$data['data_user'] = $this->model_user->data_user("WHERE username = '$username'");
		$this->load->view('user/profil/profil', $data);
	}

	public function update_profil(){

		$password = md5($this->input->post('password'));
		$username = $this->input->post('username');

	    $cek_password = $this->db->query("SELECT password FROM user WHERE username = '$username';");
		foreach ($cek_password ->result_array() as $row){
	        $password_lama      = $row['password'];
	        if($password_lama == $password){
	    		$data = array(
			      'username' => $username,
			      'nama_lengkap' => $this->input->post('nama'),
			    );

			    $res = $this->model_user->ubah_profil_user($data);
			    if($res=1){
				    header('location:'.base_url().'login');
				    $this->session->set_flashdata("pesan", "ubah-profil");
			    }
		    }else{
		    	header('location:'.base_url().'user/dashboard/profil');
				$this->session->set_flashdata("pesan", "gagal");
		    }
	    }
	}

	public function update_password(){

		$password_lama = md5($this->input->post('password_lama'));
		$password_baru = md5($this->input->post('password_baru'));
		$username = $this->input->post('username');

	    $cek_password = $this->db->query("SELECT password FROM user WHERE username = '$username';");
		foreach ($cek_password ->result_array() as $row){
	        $password_db      = $row['password'];
	        if($password_db == $password_lama){
	    		$data = array(
			      'username' => $username,
			      'password' => $password_baru,
			    );

			    $res = $this->model_user->ubah_password_user($data);
			    if($res=1){
				    header('location:'.base_url().'login');
				    $this->session->set_flashdata("pesan", "ubah-password");
			    }
		    }else{
		    	header('location:'.base_url().'user/dashboard/profil');
				$this->session->set_flashdata("pesan", "ubah-password-gagal");
		    }
	    }
	}

	public function petunjuk()
	{
		$this->load->view('user/dashboard/petunjuk');
	}

	public function kode()
	{
		$cek_kode = $this->db->query("SELECT max(kode_konsul) as maxKode FROM hasil_konsultasi");
		foreach ($cek_kode ->result_array() as $row){
	        $kode   = $row['maxKode'];
	        $noUrut = (int) substr($kode, 2, 4);
				$noUrut++;
			$kode_karakter = "KR";
			$kode 		   = $kode_karakter . sprintf("%04s", $noUrut);
			echo $kode;
	    }
	}

	// PERCOBAAN //

	public function coba()
	{
		$data['pertanyaan'] = $this->model_dashboard->coba();
		$this->load->view('user/coba', $data);
	}


}
