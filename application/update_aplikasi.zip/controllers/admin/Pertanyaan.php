<?php
defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Asia/Jakarta');

class Pertanyaan extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_pertanyaan');
		
		$authenticated = $this->session->authenticated;

		if($authenticated != true){
			$url=base_url('login/login_pakar');
			redirect($url, 'refresh');
		}
	}

	public function index()
	{
		$data['pertanyaan'] = $this->model_pertanyaan->pertanyaan();
		$this->load->view('admin/pertanyaan/pertanyaan', $data);
	}

	public function edit($kode = 0){
	    $data['pertanyaan'] = $this->model_pertanyaan->edit("WHERE kode = '$kode'");
        $this->load->view('admin/pertanyaan/edit',$data);
  	}

  	public function update(){
	    $data = array(
	      'id' => $this->input->post('id'),
	      'pertanyaan' => $this->input->post('pertanyaan'),
	    );
	    $res = $this->model_pertanyaan->update($data);
	    if($res=1){
		      header('location:'.base_url().'admin/pertanyaan');
		      $this->session->set_flashdata("pesan", "update");
	    }
	}

	public function tambah(){

		$cek_kode = $this->db->query("SELECT max(kode) as maxKode FROM pertanyaan");
		foreach ($cek_kode ->result_array() as $row){
	        $kode   = $row['maxKode'];
			$kode++;
			$kode 		   = $kode;
			$data['kode'] = $kode;
			$this->load->view('admin/pertanyaan/tambah', $data);
	    }  
  	}

  	public function simpan(){
  		//tambah kolom x di data_latih dan data normalisasi
  		$jumlah_pertanyaan         = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
  		$x_selanjutnya = $jumlah_pertanyaan + 1;

  		$tambah_kolom  = $this->db->query("ALTER TABLE data_latih ADD x$x_selanjutnya double AFTER x$jumlah_pertanyaan");
  		$tambah_kolom  = $this->db->query("ALTER TABLE data_normalisasi ADD x$x_selanjutnya double AFTER x$jumlah_pertanyaan");
  		$tambah_kolom  = $this->db->query("ALTER TABLE kolom_jawaban ADD x$x_selanjutnya double AFTER x$jumlah_pertanyaan");
  		$tambah_kolom  = $this->db->query("ALTER TABLE bobot_w ADD w$x_selanjutnya double AFTER w$jumlah_pertanyaan");

  		$timestamp = date('Y-m-d H:i:s');
  		$data = array(
		      'kode' => $this->input->post('kode'),
		      'pertanyaan' => $this->input->post('pertanyaan'),
		      'create_at' => $timestamp,
		);

		$simpan  = $this->model_pertanyaan->simpan('pertanyaan', $data);
		if($simpan){
			header('location:'.base_url().'admin/pertanyaan');
		    $this->session->set_flashdata("pesan", "tambah");
		}
  	}

  	public function hapus($kode_id = 0){
  		$jumlah_pertanyaan_sebelum = $this->db->query("SELECT * FROM pertanyaan")->num_rows();
  		if($jumlah_pertanyaan_sebelum == 1){
  			header('location:'.base_url().'admin/pertanyaan');
		    $this->session->set_flashdata("pesan", "maaf");
  		}else{
	  		//hapus pertanyaan sesuai id
	  		$result = $this->model_pertanyaan->hapus('pertanyaan',array('kode' => $kode_id));

	        $jumlah_pertanyaan_sesudah = $this->db->query("SELECT * FROM pertanyaan")->num_rows();

		    $banyak_x = $jumlah_pertanyaan_sebelum - $kode_id;
		    if($banyak_x > 0){
		    	for ($i=1; $i <= $banyak_x ; $i++) { 

	        		$tambah_kode_x = $kode_id + $i;
	        		$min_kode_x    = $tambah_kode_x - 1;

			        $rubah_kode_x1  = $this->db->query("UPDATE pertanyaan SET kode = $min_kode_x WHERE kode = $tambah_kode_x");
	        	}
		    }

	        // perubahan kode x //
	        $kode_x = "x$kode_id";
	        $kode_w = "w$kode_id";
	        $hapus1 = $this->db->query("ALTER TABLE data_latih DROP $kode_x;");
	        $hapus2 = $this->db->query("ALTER TABLE data_normalisasi DROP $kode_x;");
	        $hapus3 = $this->db->query("ALTER TABLE kolom_jawaban DROP $kode_x;");
	        $hapus4 = $this->db->query("ALTER TABLE bobot_w DROP $kode_w;");

	        // ambil total x setelah x yang dihapus
	        $banyak_x = $jumlah_pertanyaan_sebelum - $kode_id;

	        if($banyak_x > 0){
	        	// update kode x
	        	for ($i=1; $i <= $banyak_x ; $i++) { 

	        		$tambah_kode_x = $kode_id + $i;
	        		$min_kode_x    = $tambah_kode_x - 1;
			        $kode_x_rubah  = "x$tambah_kode_x";
			        $kode_x_min    = "x$min_kode_x";

			        $kode_w_rubah  = "w$tambah_kode_x";
			        $kode_w_min    = "w$min_kode_x";

			        $rubah_kode_x1  = $this->db->query("ALTER TABLE data_latih CHANGE $kode_x_rubah $kode_x_min double;");
			        $rubah_kode_x2  = $this->db->query("ALTER TABLE data_normalisasi CHANGE $kode_x_rubah $kode_x_min double;");
			        $rubah_kode_x3  = $this->db->query("ALTER TABLE kolom_jawaban CHANGE $kode_x_rubah $kode_x_min double;");
			        $rubah_kode_x4  = $this->db->query("ALTER TABLE bobot_w CHANGE $kode_w_rubah $kode_w_min double;");
	        	}
	        }
		    header('location:'.base_url().'admin/pertanyaan');
		    $this->session->set_flashdata("pesan", "hapus");
		}
	}

	public function hapus_semua(){

		$hapus = $this->db->query("TRUNCATE pertanyaan");
		if($hapus){
			header('location:'.base_url().'admin/pertanyaan');
		    $this->session->set_flashdata("pesan", "hapus_semua");
		}
  	}

}
