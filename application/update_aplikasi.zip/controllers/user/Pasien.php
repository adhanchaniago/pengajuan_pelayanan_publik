<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('model_pasien');
		if($this->session->userdata('masuk') != TRUE){
			$url=base_url('login');
			redirect($url);
		}
	}

	public function index()
	{
		$data['data_pasien'] = $this->model_pasien->data_pasien();
		$this->load->view('user/pasien/pasien', $data);
	}

	public function detail_pasien(){
		$username = $this->session->username;
	    $data['detail_pasien'] = $this->model_pasien->detail_pasien("WHERE user.`username` = '$username'");
        $this->load->view('user/profil/detail',$data);
  	}

  	public function edit($kode_id = 0){
	    $data['data_pasien'] = $this->model_pasien->edit_pasien("WHERE user.`id` = '$kode_id'");
        $this->load->view('user/profil/edit',$data);
  	}

  	public function update(){
  		$kode_id = $this->input->post('kode_id');

	    $data = array(
	      'id_user' => $this->input->post('kode_id'),	
	      'tempat_lahir' => $this->input->post('tempat_lahir'),
	      'tgl_lahir' => $this->input->post('tgl_lahir'),
	      'nama_suami' => $this->input->post('nama_suami'),
	      'pekerjaan' => $this->input->post('pekerjaan'),
	      'agama' => $this->input->post('agama'),
	      'alamat' => $this->input->post('alamat'),
	      'status_kawin' => $this->input->post('status_kawin'),
	      'usia_kawin' => $this->input->post('usia_kawin'),
	      'kawin_ke' => $this->input->post('kawin_ke'),
	      'status_hamil' => $this->input->post('status_hamil'),
	      'usia_hamil' => $this->input->post('usia_hamil'),
	      'anak_ke' => $this->input->post('anak_ke'),
	    );

	    $data2 = array(
	      'id' => $this->input->post('kode_id'),
	      'nama_lengkap' => $this->input->post('nama_lengkap'),
	    );

	    $res  = $this->model_pasien->update_pasien($data);
	    $res2 = $this->model_pasien->update_pasien2($data2);

	    if($res=1){
		      header('location:'.base_url().'user/pasien/detail_pasien');
		      $this->session->set_flashdata("pesan", "update-pasien");
	    }
	}

}
